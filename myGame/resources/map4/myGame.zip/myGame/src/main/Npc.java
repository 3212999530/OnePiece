package main;


import javax.swing.*;
import java.util.ArrayList;
import java.util.Date;

//小怪
class Enemy extends Item{

    public Enemy(String url,int x,int y,String name,String s,String sound,int hp,int atk,int dfc,int money){
        this.x=x;
        this.slogan=s;
        this.url=url;
        this.sound=new Sound(sound);
        this.y=y;
        this.name=name;
        this.type="Enemy";
        this.url=url;
        this.pic=new Label(url,x,y);
        this.hp=hp;
        this.atk=atk;
        this.dfc=dfc;
        this.money=money;
    }

    public Enemy(String url,int x,int y,String name,String s,String sound,int hp,int atk,int dfc,int money,Item []left,String []change ){
        this.x=x;
        this.slogan=s;
        this.url=url;
        this.left=left;
        this.change=change;
        this.sound=new Sound(sound);
        this.y=y;
        this.name=name;
        this.type="Enemy";
        this.url=url;
        this.pic=new Label(url,x,y);
        this.hp=hp;
        this.atk=atk;
        this.dfc=dfc;
        this.money=money;
    }

}

//boss


//商店
class Goods{
    protected String url;
    protected String name;
    protected String ics,dcs;
    protected Integer num1,num2;
    public Goods(String url,String ics,Integer num1,String dcs,Integer num2){

        this.ics=ics;
        this.dcs=dcs;
        this.url=url;
        this.num1=num1;
        this.num2=num2;
    }

}
class Shop extends Item{

    public Shop(String url,int x,int y,String name,String s,String sound,Goods gs[]){
        this.sound=new Sound(sound);

        this.goods=gs;
        this.type="Shop";
        this.slogan=s;
        this.name=name;
        this.x=x;
        this.y=y;
        this.url=url;
        this.pic=new Label(url,x,y);
    }



}


//友方



class Friend extends Item{

    public Friend(String url,int x,int y,String name,String s,String sound,Item []left,String []change ){
        this.sound=new Sound(sound);
        this.change=change;
        this.name=name;
        this.slogan=s;
        this.type="Friend";
        this.left=left;
        this.x=x;
        this.y=y;
        this.url=url;
        this.pic=new Label(url,x,y);

    }
    public Friend(String url,int x,int y,String name,String s,String sound){
        this.sound=new Sound(sound);
        this.left=null;
        this.change=null;
        this.slogan=s;
        this.type="Friend";
        this.name=name;
        this.x=x;
        this.y=y;
        this.url=url;
        this.pic=new Label(url,x,y);

    }
}

//钱庄
class Bank extends Item{


    //钱是否够  够的话就升级

    public Bank(String url, int x, int y, String name, String s, String sound, Date lastTime,int rank){
        this.lastTime=lastTime;
        this.rank=rank;
        this.money=10;
        this.sound=new Sound(sound);
        this.type="Bank";
        this.url=url;
        this.slogan=s;
        this.name=name;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
//地图资源
class Clue extends Item{

    public Clue(int x,int y,String s,String sound){
        this.sound=new Sound(sound);

        this.slogan=s;
        this.url="resources/线索.png";
        this.type="Clue";
        this.name="线索";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Medicine extends Item{

    public Medicine(String url,int x,int y,String name,String s,String sound,int hp){
        this.sound=new Sound(sound);

        this.hp=hp;
        this.type="Medicine";
        this.url=url;
        this.slogan=s;
        this.name=name;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Swords extends Item{

    public Swords(String url,int x,int y,String name,String s,String sound,int atk){
        this.sound=new Sound(sound);

        this.atk=atk;
        this.type="Swords";
        this.slogan=s;
        this.url=url;
        this.name=name;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}

class Shield extends Item{

    public Shield(String url,int x,int y,String name,String s,String sound,int dfc){
        this.sound=new Sound(sound);

        this.dfc=dfc;
        this.url=url;
        this.slogan=s;
        this.name=name;
        this.type="Shield";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}


class Boat extends Item{
    public Boat(String url,int x,int y,String s,int dst){
        this.dst=dst;
        this.slogan=s;
        this.type="Boat";
        this.url=url;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Coin extends Item{
    public Coin(String url,int x,int y,String name,String s,String sound,int money){
        this.sound=new Sound(sound);

        this.slogan=s;
        this.name=name;
        this.type="Coin";
        this.money=money;
        this.url=url;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Car extends Item{

    public Car(String url,int x,int y,String name,String s,String sound,int dstX,int dstY,String runSound){
        this.sound=new Sound(sound);
        this.runSound=new Sound(runSound);
        this.slogan=s;
        this.dstX=dstX;
        this.dstY=dstY;
        this.url=url;
        this.name=name;
        this.type="Car";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}

class  Blocker extends Item{
    public Blocker(String url,int x,int y,String name,String s,String sound){
        this.sound=new Sound(sound);
        this.slogan=s;
        this.url=url;
        this.name=name;
        this.type="Empty";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}


class Pt{
    protected int x;
    protected int y;
    public Pt(int x,int y){
        this.x=x;
        this.y=y;
    }
}

class Door extends Item{
    public Door(int x, int y, ArrayList<Pt> area){

        this.area=area;
        this.type="Door";
        this.x=x;
        this.y=y;
    }
}

class Empty extends Item{
    public Empty(int x,int y){
        this.type="Empty";
        this.x=x;
        this.y=y;
    }
}

class Buff1 extends Item{
    public Buff1(String url,int x,int y,String name,String s,String sound){
        this.sound=new Sound(sound);
        this.slogan=s;
        this.url=url;
        this.name=name;
        this.type="Buff1";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Buff2 extends Item{
    public Buff2(String url,int x,int y,String name,String s,String sound){
        this.sound=new Sound(sound);
        this.slogan=s;
        this.url=url;
        this.name=name;
        this.type="Buff1";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}
class Buff3 extends Item{
    public Buff3(String url,int x,int y,String name,String s,String sound){
        this.sound=new Sound(sound);
        this.slogan=s;
        this.url=url;
        this.name=name;
        this.type="Buff1";
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
    }
}

class Fog extends Item{
    public Fog(int x,int y){
        this.x=x;
        this.y=y;
        this.type="Fog";
    }
}

//class MultiMan extends Item{
//
//    public MultiMan(ArrayList<Item> personalities){
//        this.personalities=personalities;
//        cur=0;
//    }
//    public changePersonality(int p){
//
//
//
//        Item lastPersonality=personalities.get(cur);
//        Main.map.clear(lastPersonality.x,lastPersonality.x);
//        Main.map.add(lastPersonality);
//        cur=p;
//
//    }
//}