package main;

import java.util.Date;
import javax.swing.*;
import java.util.ArrayList;

public class Item {

    protected ArrayList<Pt> area;
    protected Sound sound;
    protected Sound runSound;
    protected Item []left;
    protected String []change;
    protected Integer hp,atk,dfc,money;
    protected String name;
    protected String slogan;
    protected int x,y;
    protected String type;
    protected Label pic;
    protected String url;
    protected int dst;
    protected int dstX,dstY;
    protected Goods []goods;
    protected int rank;
    protected Date lastTime;


    protected int cur;
    protected ArrayList<Item> personalities;
    public Item(){

    }
    public Item(String s){
        type=s;
    }
    public void afterPress(){
    }

}
class Label extends JLabel {
    //protected JLabel img=new JLabel();
    protected int x=0,y=0;

    public final static int width=55,height=55;
    public Label(String url, int x, int y){
        this.x=x;
        this.y=y;
        this.setIcon(new ImageIcon(url));
        this.setBounds(width*y,height*x,width,height);
        this.setOpaque(false);
    }

    public void update(String url){
        Main.c.remove(this);
        this.setIcon(new ImageIcon(url));
        Main.c.add(this);
    }
}
class Floor extends Item{
    public static String url="resources/floor.png";

    public Floor(int x,int y){
        this.x=x;
        this.y=y;
        this.type="Floor";
        this.pic=new Label(url,x,y);

    }
}


class Water extends Item{
    public static String url="resources/wall.png";
    public Water(){

    }
    public Water(int x,int y){
        this.x=x;
        this.y=y;
        this.type="Wall";
        this.pic=new Label(url,x,y);
    }
}

class Tree extends Item{
    public static String url="resources/tree.png";
    public Tree(int x,int y){
        this.x=x;
        this.y=y;
        this.type="Wall";
        this.pic=new Label(url,x,y);
    }
}
class Wall extends Item{
    public static String url="resources/map3/wall3.jpg";
    public Wall(int x,int y){
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
        this.type="Wall";
    }
    public Wall(String url,int x,int y){
        this.url=url;
        this.x=x;
        this.y=y;
        this.pic=new Label(url,x,y);
        this.type="Wall";
    }
}
