package main;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Bgm implements Runnable{//1.实现Runnable接口
    protected String path;
    private Player player ;
    @Override
    public void run() {
        try {
            while(true){
                System.out.println("开始播放");
                player = new Player(new FileInputStream(new File(path)));
                player.play();
                System.out.println("结束播放"+ player.toString());
            }
        } catch (JavaLayerException e) {
            throw new RuntimeException(e);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public Bgm(String path){
        this.path=path;
    }
}


class Sound implements Runnable{//1.实现Runnable接口
    protected String path;
    protected Player player ;
    @Override
    public void run() {//2.重写run方法
        try {
            player = new Player(new FileInputStream(new File(path)));
            player.play();//播放
        } catch (JavaLayerException e) {
            throw new RuntimeException(e);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public Sound(){

    }
    public Sound(String path){
        this.path=path;
    }

}

class CoinSound extends Sound{
    public CoinSound(){
        this.path="resources/金币.mp3";
    }
}

class BoatSound extends Sound{
    public BoatSound(){
        this.path="resources/划船.mp3";
    }
}

