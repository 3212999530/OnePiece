package main;

import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class User extends Item {
    public static String url1="resources/路飞正面照片.png",url2="resources/路飞背面照片.png",url3="resources/路飞左面照片.png",url4="resources/路飞右面照片.png";
    protected Integer hp=4,atk=300,dfc=1,money=300;
    protected boolean buff1,buff2,buff3;
    protected Label pic;
//    返回可否击败，可以便获取战利品
    public int attack(Item enemy,boolean sit){
        int myAtk=atk,itAtk=enemy.atk,myDfc=dfc,itDfc= enemy.dfc;
        if(buff1){
            myAtk*=2;
            buff1=false;
        }

        if(buff2){
            myDfc*=2;
            buff2=false;
        }
        if(buff3){
            itDfc=(itDfc+1)/2;
            itAtk=(itAtk+1)/2;
            buff3=false;
        }
        if(myAtk<=itDfc){
            return -1;
        }
        int dt=((enemy.hp+myAtk-itDfc-1)/(myAtk-itDfc)-1)*(Math.max(itAtk - myDfc, 0));
        if(sit&&dt<hp){
            hp-=dt;
            money+=enemy.money;
        }
        return hp-dt;
    }
    public void move(int dir){
        int nx=x,ny=y;
        switch (dir){
            case 0:nx--;break;
            case 1:ny++;break;
            case 2:nx++;break;
            case 3:ny--;break;
        }
        if(Main.curSound!=null) {
            Main.curSound.stop();
            while(Main.curSound.isAlive()){

            }
        }
        if(Main.map.mp[nx][ny]==null){
            if(Main.graph.curMap!=7){
                Main.infoBar.showInfo(null,nx,ny);
                x=nx;
                y=ny;
                pic.setBounds(pic.width*y,pic.height*x,pic.width,pic.height);
            }
            else{
                Main.map.mask[x][y]=new Label("resources/wall.png",x,y);
                Main.map.mask[x+1][y]=new Label("resources/wall.png",x+1,y);
                Main.map.mask[x][y+1]=new Label("resources/wall.png",x,y+1);
                Main.map.mask[x-1][y]=new Label("resources/wall.png",x-1,y);
                Main.map.mask[x][y-1]=new Label("resources/wall.png",x,y-1);
                x=nx;
                y=ny;
                pic.setBounds(pic.width*y,pic.height*x,pic.width,pic.height);
                Main.map.mask[x][y]=null;
                Main.map.mask[x+1][y]=null;
                Main.map.mask[x][y+1]=null;
                Main.map.mask[x-1][y]=null;
                Main.map.mask[x][y-1]=null;
                Main.map.clearScr();
                Main.c.remove(pic);
                Main.c.add(pic,0);
                Main.map.addTo();
            }

        }
        else if(Objects.equals(Main.map.mp[nx][ny].type, "Door")){
            x=nx;
            y=ny;
            pic.setBounds(pic.width*y,pic.height*x,pic.width,pic.height);
            ArrayList<Pt> area=Main.map.mp[x][y].area;
            //Main.map.clearScr();
            for(Pt i:area){
                Main.c.remove(Main.map.mask[i.x][i.y]);
                if(Main.map.mp[i.x][i.y]!=null&&Main.map.mp[i.x][i.y].pic!=null)Main.c.add(Main.map.mp[i.x][i.y].pic,0);
                Main.map.mask[i.x][i.y]=null;
            }
            Main.c.remove(pic);
            Main.c.add(pic,0);
            Main.map.mp[x][y]=null;
            //Main.map.addTo();
        }
        else if(Objects.equals(Main.map.mp[nx][ny].type, "Wall")){
            Main.infoBar.showInfo(null,nx,ny);
        }
        else{
            Main.infoBar.showInfo(Main.map.mp[nx][ny],nx,ny);
        }

    }
    public User(int x, int y){
        this.x=x;
        this.y=y;
        this.type="Player";
        pic=new Label(url1,x,y);
    }
}
